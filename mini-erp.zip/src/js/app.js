// Main JS
console.log('Mini ERP loaded');