# Mini ERP

Estructura base lista para GitHub.
